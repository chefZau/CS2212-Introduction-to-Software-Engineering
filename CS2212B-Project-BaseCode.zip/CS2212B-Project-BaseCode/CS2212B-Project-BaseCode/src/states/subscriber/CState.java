package states.subscriber;

import events.AbstractEvent;

public class CState extends AbstractState{

	protected CState() {
		
	}
	
	public void handleEvent(AbstractEvent event, String channelName) {
		System.out.format("handles it at state C \n");
	}
	
}
