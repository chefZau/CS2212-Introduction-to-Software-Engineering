package states.subscriber;

import events.AbstractEvent;

public class DefaultState extends AbstractState{

	protected DefaultState() {
		
	}
	
	public void handleEvent(AbstractEvent event, String channelName) {
		System.out.format("handles it at state default \n");
	}
	
}
