package states.subscriber;

import events.AbstractEvent;

public class AState extends AbstractState{
	
	protected AState() {
		
	}
	
	public void handleEvent(AbstractEvent event, String channelName) {
		System.out.format("handles it at state A \n");
	}
	
}
