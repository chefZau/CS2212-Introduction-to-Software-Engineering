//CHANGED
package strategies.publisher;

import java.util.List;

import events.AbstractEvent;
import events.EventFactory;
import events.EventMessage;
import events.EventType;
import pubSubServer.ChannelEventDispatcher;

public class AStrategy extends AbstractStrategy {
	private List<String> listOfChannels; //TODO channels on which to publish
	private EventType defaultEventType; //TODO
	private String defaultHeader, defaultBody; //TODO
	
	
	protected AStrategy() {
		listOfChannels = null;
		defaultEventType = null;
		defaultHeader = defaultBody = null;
	}
	
	public void doPublish(int publisherId) {
		EventMessage message = new EventMessage(defaultHeader, defaultBody);
		AbstractEvent event = EventFactory.createEvent(defaultEventType, publisherId, message);
		ChannelEventDispatcher.getInstance().postEvent(event, listOfChannels);
	}


	public void doPublish(AbstractEvent event, int publisherId) {
		ChannelEventDispatcher.getInstance().postEvent(event, listOfChannels);
	}

}
