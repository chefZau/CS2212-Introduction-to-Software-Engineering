package strategies.publisher;

import events.AbstractEvent;
import events.EventFactory;

public abstract class AbstractStrategy implements IStrategy{


	public abstract void doPublish(int publisherId);
	
	public abstract void doPublish(AbstractEvent event, int publisherId);
}
