package baseEntities;


 
 /**
  * @author kkontog, ktsiouni, mgrigori
  *  
  * Base Interface for Publisher and Subscriber classes
  */
public interface IEntity {

}
